// pages/news/list/list.js
let app=getApp();
let url = app.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputShowed: false,
    inputVal: "",
    data:[],
    page:1,
    url:url,
    radioVal:'',
    hide:true,
    radioItems: [
      {name: '按名称搜索', value: 1},
      {name: '按城市搜索', value: 2, checked: true},
      {name: '按类型搜索', value: 3, }
    ],
  },
  showInput: function () {
    this.setData({
      inputShowed: true
    });
  },
  hideInput: function () {
    this.setData({
      inputVal: "",
      inputShowed: false
    },()=>{
      this.fetchData();
    });
  },
  clearInput: function () {
    this.setData({
      inputVal: ""
    });
  },
  inputTyping: function (e) {
    this.setData({
      inputVal: e.detail.value
    });
  },
  fetchData:function(){
    wx.showLoading({
      title:"加载中"
    });
    let obj={
      page:this.data.page,
    };
    if (this.data.radioVal===1){
      obj.name=this.data.inputVal
    } else if (this.data.radioVal===2){
      obj.city=this.data.inputVal
    } else {
      obj.type=this.data.inputVal
    }
    wx.request({
      url:url+"/site",
      data:obj,
      success:(res)=>{
        if (res.data.code===200){
          this.setData({
            data:[...this.data.data,...res.data.data],
            total:res.data.total,
            inputShowed:false
          })
        }
      },
      complete:()=>{
        wx.hideLoading()
      }
    })

  },
  radioChange: function (e) {
    let value = e.detail.value*1;
    this.data.radioItems.forEach(obj=>{
      obj.checked=obj.value===value;
    })
    this.setData({
      radioItems: this.data.radioItems,
      radioVal:value
    });
  },
  search:function (){
    this.setData({
      data:[],
      page:1,
    },()=>{
      console.log(1);
      this.fetchData();
    })
  },
  totop:function(){
    wx.pageScrollTo({
      scrollTop:0,
      duration:300
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.fetchData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    let {total,page}=this.data;
    if (page*10>total){
      this.setData({
        hide:false
      });
      return
    }
    this.setData({
      page:this.data.page+1,
    });
    this.fetchData();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})